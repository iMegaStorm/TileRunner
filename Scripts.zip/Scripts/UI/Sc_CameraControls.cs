using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sc_CameraControls : MonoBehaviour
{

    //[SerializeField] Transform myTransform = null;
    //float cameraPitch = 0f;
    //[SerializeField] public float mouseSens = 3.5f;

    //void Update()
    //{
    //    Vector2 mouseDelta = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));

    //    cameraPitch -= mouseDelta.y * mouseSens * Time.deltaTime;

    //    cameraPitch = Mathf.Clamp(cameraPitch, -90f, 90);

    //    myTransform.localEulerAngles = Vector3.right * cameraPitch;

    //    transform.Rotate(Vector3.up * mouseDelta.x * mouseSens * Time.deltaTime);
    //}
}
